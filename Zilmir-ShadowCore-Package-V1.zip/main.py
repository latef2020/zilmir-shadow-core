print('Zilmir Shadow Core Activated')
