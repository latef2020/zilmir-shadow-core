# Zilmir Shadow Core

This is the core system for Zilmir's autonomous deployment.
